# Smart Pantry Manager — Advanced Java Edition

Smart Pantry Manager is an offline-first Android app written in **Java**. It helps people reduce food waste by tracking ingredients and suggesting only recipes they can cook with the ingredients and quantities they already have.

## Features

- Five Activities/screens: Pantry Dashboard, Add/Edit Ingredient, Suggested Recipes, Recipe Details, and Settings.
- Full pantry CRUD (create, read, update and delete) backed by SQLite; records persist across app restarts.
- Searchable pantry list, quantity/unit display, optional expiry dates, and an expiring-soon visual indicator for dates within the next three days.
- Twenty preloaded recipes, each with a required ingredient list, quantities, units and method.
- **Strict recipe matching:** a recipe is suggested only if every required ingredient exists in the pantry in sufficient quantity. Partial matches are never placed in the main suggestions list.
- Ingredient-name normalisation for common plural forms and measurement conversion for compatible units such as kg/g, l/ml and tbsp/tsp.
- Friendly empty states and validation messages, custom ListView adapters, and Intent-based navigation.
- Manual GitHub Actions workflow to build a debug APK on a hosted runner.

## Technology choices

- **Java:** required by the Mobile App Development 700 assignment.
- **SQLite (`SQLiteOpenHelper`):** reliable on-device persistence without needing a server or internet connection during normal app use.
- **ListView + custom `BaseAdapter`:** demonstrates dynamic database-backed lists and custom row layouts.
- **Android Activities + Intents:** each core task has a distinct screen and selected record IDs are passed between screens.

## Build with Android Studio

1. Open the `SmartPantryManager` project folder in Android Studio.
2. Use JDK 17 and Android SDK Platform 35 (or adjust `compileSdk` to an installed compatible SDK).
3. Allow Gradle to sync, then run the `app` configuration on an emulator or Android device.
4. On first launch, SQLite creates the tables and seeds the 20 recipes. The user's pantry begins empty.

## Build APK in GitHub Actions

Open the repository's **Actions** tab, select **Build Smart Pantry Manager APK**, choose **Run workflow**, and wait for the job to finish. Download the `SmartPantryManager-debug-apk` artifact from the completed run. A successful workflow is required before treating the APK as ready to install.

## Screen flow

`Pantry Dashboard → Add/Edit Ingredient`  
`Pantry Dashboard → Suggested Recipes → Recipe Details`  
`Any main screen → Settings`

## Database model

- `pantry_items(id, name, quantity, unit, expiry_date)`
- `recipes(id, name, steps)`
- `recipe_ingredients(id, recipe_id, name, quantity, unit)`

`recipe_ingredients.recipe_id` refers to `recipes.id`. The matcher reads each recipe's requirements and compares them with pantry records before displaying it as a suggestion.

## Strict matching: the rule to defend in the demo

For every required recipe ingredient, the matcher normalises the ingredient name and unit, sums pantry quantities in compatible units, and compares the available amount with the required amount. If even one ingredient is missing, incompatible, or insufficient, `canMake()` returns `false`. For example, a recipe requiring two eggs will not be suggested if only one egg is in the pantry.

## Before submission

- Run and test all CRUD actions on a real emulator/device.
- Test at least one positive and one negative strict-matching case, including a quantity shortage.
- Capture actual screenshots from your running app; do not use mockups as evidence.
- Record a 5–7 minute narrated demonstration and include it with the report and source project in the final submission ZIP.
- Complete your own report, student details and reflection. Do not claim features you have not tested. The expiry indicator is a visual in-app status; it does **not** schedule Android notifications.

## Project layout

- `app/src/main/java/com/teybrag/smartpantry/` — Activities, models, SQLite helper, adapters and strict matcher.
- `app/src/main/res/values/styles.xml` — app theme.
- `.github/workflows/android.yml` — hosted Android build workflow.
