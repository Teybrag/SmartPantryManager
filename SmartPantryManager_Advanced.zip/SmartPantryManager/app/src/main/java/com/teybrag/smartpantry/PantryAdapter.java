package com.teybrag.smartpantry;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Custom ListView adapter that presents ingredient quantity and expiry status. */
public class PantryAdapter extends BaseAdapter {
    private final Activity activity;
    private final List<PantryItem> items;

    public PantryAdapter(Activity activity, List<PantryItem> items) { this.activity = activity; this.items = items; }
    @Override public int getCount() { return items.size(); }
    @Override public Object getItem(int position) { return items.get(position); }
    @Override public long getItemId(int position) { return items.get(position).id; }

    @Override public View getView(int position, View convertView, ViewGroup parent) {
        PantryItem item = items.get(position);
        LinearLayout card = new LinearLayout(activity);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(Ui.dp(activity, 15), Ui.dp(activity, 12), Ui.dp(activity, 15), Ui.dp(activity, 12));
        card.setBackground(Ui.round(activity, Ui.WHITE, 14));
        TextView name = Ui.text(activity, item.name, 17, Ui.DARK, true);
        card.addView(name);
        String quantity = String.format(Locale.getDefault(), "%s %s", format(item.quantity), item.unit);
        TextView detail = Ui.text(activity, quantity, 13, Ui.MUTED, false);
        detail.setPadding(0, Ui.dp(activity, 4), 0, 0);
        card.addView(detail);
        if (item.expiryDate != null && !item.expiryDate.trim().isEmpty()) {
            boolean soon = isExpiringSoon(item.expiryDate);
            TextView expiry = Ui.text(activity, (soon ? "⚠  Expiring soon · " : "Expiry · ") + item.expiryDate,
                    12, soon ? 0xFFB45309 : Ui.MUTED, soon);
            expiry.setPadding(0, Ui.dp(activity, 3), 0, 0);
            card.addView(expiry);
        }
        LinearLayout.LayoutParams params = Ui.lp(activity, -1, -2);
        params.bottomMargin = Ui.dp(activity, 8);
        card.setLayoutParams(params);
        return card;
    }

    private boolean isExpiringSoon(String value) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT);
            format.setLenient(false);
            Date date = format.parse(value);
            if (date == null) return false;
            long days = (date.getTime() - System.currentTimeMillis()) / (24L * 60L * 60L * 1000L);
            return days >= 0 && days <= 3;
        } catch (Exception ignored) { return false; }
    }

    private String format(double value) { return value == (long) value ? String.valueOf((long) value) : String.valueOf(value); }
}
