package com.teybrag.smartpantry;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "smart_pantry.db";
    private static final int DB_VERSION = 1;

    public DatabaseHelper(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE pantry_items (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, quantity REAL NOT NULL, unit TEXT NOT NULL, expiry_date TEXT)");
        db.execSQL("CREATE TABLE recipes (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, steps TEXT NOT NULL)");
        db.execSQL("CREATE TABLE recipe_ingredients (id INTEGER PRIMARY KEY AUTOINCREMENT, recipe_id INTEGER NOT NULL, name TEXT NOT NULL, quantity REAL NOT NULL, unit TEXT NOT NULL, FOREIGN KEY(recipe_id) REFERENCES recipes(id) ON DELETE CASCADE)");
        seedRecipes(db);
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS recipe_ingredients");
        db.execSQL("DROP TABLE IF EXISTS recipes");
        db.execSQL("DROP TABLE IF EXISTS pantry_items");
        onCreate(db);
    }

    public long addPantryItem(String name, double quantity, String unit, String expiry) {
        ContentValues v = new ContentValues(); v.put("name", name.trim()); v.put("quantity", quantity); v.put("unit", unit.trim()); v.put("expiry_date", expiry == null ? "" : expiry.trim());
        return getWritableDatabase().insert("pantry_items", null, v);
    }
    public int updatePantryItem(long id, String name, double quantity, String unit, String expiry) {
        ContentValues v = new ContentValues(); v.put("name", name.trim()); v.put("quantity", quantity); v.put("unit", unit.trim()); v.put("expiry_date", expiry == null ? "" : expiry.trim());
        return getWritableDatabase().update("pantry_items", v, "id=?", new String[]{String.valueOf(id)});
    }
    public int deletePantryItem(long id) { return getWritableDatabase().delete("pantry_items", "id=?", new String[]{String.valueOf(id)}); }

    public List<PantryItem> getAllPantryItems() {
        List<PantryItem> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id,name,quantity,unit,expiry_date FROM pantry_items ORDER BY name COLLATE NOCASE", null)) {
            while (c.moveToNext()) out.add(new PantryItem(c.getLong(0), c.getString(1), c.getDouble(2), c.getString(3), c.getString(4)));
        }
        return out;
    }
    public PantryItem getPantryItem(long id) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id,name,quantity,unit,expiry_date FROM pantry_items WHERE id=?", new String[]{String.valueOf(id)})) {
            if (c.moveToFirst()) return new PantryItem(c.getLong(0), c.getString(1), c.getDouble(2), c.getString(3), c.getString(4));
        }
        return null;
    }

    public List<Recipe> getAllRecipes() {
        List<Recipe> out = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT id,name,steps FROM recipes ORDER BY name COLLATE NOCASE", null)) {
            while (c.moveToNext()) {
                Recipe r = new Recipe(c.getLong(0), c.getString(1), c.getString(2));
                try (Cursor ic = db.rawQuery("SELECT id,recipe_id,name,quantity,unit FROM recipe_ingredients WHERE recipe_id=? ORDER BY id", new String[]{String.valueOf(r.id)})) {
                    while (ic.moveToNext()) r.ingredients.add(new RecipeIngredient(ic.getLong(0), ic.getLong(1), ic.getString(2), ic.getDouble(3), ic.getString(4)));
                }
                out.add(r);
            }
        }
        return out;
    }
    public Recipe getRecipe(long id) {
        for (Recipe r : getAllRecipes()) if (r.id == id) return r;
        return null;
    }

    private static void seedRecipes(SQLiteDatabase db) {
        // Seed 20 recipes only when the database is first created.
        Object[][] recipes = new Object[][]{
            {"Tomato Omelette", "1. Beat the eggs. 2. Chop the tomatoes and onion. 3. Cook everything in a lightly oiled pan until the eggs are set.", new Object[][]{{"eggs",2,"pcs"},{"tomatoes",1,"pcs"},{"onion",0.5,"pcs"},{"salt",1,"tsp"}}},
            {"Egg Fried Rice", "1. Heat a pan. 2. Scramble the eggs. 3. Add cooked rice, peas and soy sauce; stir-fry until hot.", new Object[][]{{"cooked rice",2,"cups"},{"eggs",2,"pcs"},{"peas",0.5,"cups"},{"soy sauce",1,"tbsp"}}},
            {"Tomato Pasta", "1. Boil the pasta. 2. Cook chopped tomatoes and garlic in olive oil. 3. Mix with the drained pasta.", new Object[][]{{"pasta",200,"g"},{"tomatoes",2,"pcs"},{"garlic",2,"cloves"},{"olive oil",1,"tbsp"}}},
            {"Potato Hash", "1. Dice the potatoes and onion. 2. Heat oil in a pan. 3. Fry until tender and golden, then season with salt.", new Object[][]{{"potatoes",2,"pcs"},{"onion",1,"pcs"},{"oil",1,"tbsp"},{"salt",1,"tsp"}}},
            {"Banana Pancakes", "1. Mash the bananas. 2. Whisk with eggs, flour and milk. 3. Cook small pancakes in a lightly greased pan.", new Object[][]{{"bananas",2,"pcs"},{"eggs",2,"pcs"},{"flour",100,"g"},{"milk",100,"ml"}}},
            {"Cheese Toast", "1. Place cheese between bread slices. 2. Spread butter on the outside. 3. Toast in a pan until crisp and the cheese melts.", new Object[][]{{"bread",2,"slices"},{"cheese",50,"g"},{"butter",10,"g"}}},
            {"Vegetable Stir-Fry", "1. Slice the cabbage, carrot and onion. 2. Stir-fry until just tender. 3. Add soy sauce and toss well.", new Object[][]{{"cabbage",100,"g"},{"carrot",1,"pcs"},{"onion",1,"pcs"},{"soy sauce",1,"tbsp"}}},
            {"Chicken Wrap", "1. Cook the chicken fully and slice it. 2. Add chicken, lettuce and tomato to tortillas. 3. Roll and serve.", new Object[][]{{"chicken",150,"g"},{"tortillas",2,"pcs"},{"lettuce",50,"g"},{"tomato",1,"pcs"}}},
            {"Banana Oat Bowl", "1. Put oats in a bowl. 2. Add milk and sliced banana. 3. Drizzle with honey and serve.", new Object[][]{{"oats",50,"g"},{"milk",150,"ml"},{"banana",1,"pcs"},{"honey",1,"tsp"}}},
            {"Garlic Butter Pasta", "1. Boil the pasta. 2. Gently cook garlic in butter. 3. Toss with pasta and grated parmesan.", new Object[][]{{"pasta",200,"g"},{"garlic",2,"cloves"},{"butter",20,"g"},{"parmesan",20,"g"}}},
            {"Tuna Sandwich", "1. Drain and flake the tuna. 2. Mix with mayonnaise and chopped onion. 3. Fill the bread slices.", new Object[][]{{"bread",2,"slices"},{"tuna",1,"can"},{"mayonnaise",1,"tbsp"},{"onion",0.25,"pcs"}}},
            {"Chickpea Salad", "1. Drain the chickpeas. 2. Chop cucumber and tomato. 3. Mix everything with lemon juice.", new Object[][]{{"chickpeas",150,"g"},{"cucumber",1,"pcs"},{"tomato",1,"pcs"},{"lemon",1,"pcs"}}},
            {"Spinach Omelette", "1. Beat the eggs. 2. Wilt spinach in butter. 3. Add eggs and cheese and cook until set.", new Object[][]{{"eggs",2,"pcs"},{"spinach",50,"g"},{"cheese",30,"g"},{"butter",10,"g"}}},
            {"Apple Oat Porridge", "1. Heat oats with milk, stirring. 2. Dice and add the apple. 3. Cook until creamy and add cinnamon.", new Object[][]{{"oats",50,"g"},{"milk",200,"ml"},{"apple",1,"pcs"},{"cinnamon",1,"tsp"}}},
            {"Bean Quesadilla", "1. Mash the beans lightly. 2. Add beans, cheese and onion to a tortilla. 3. Fold and toast on both sides.", new Object[][]{{"tortillas",2,"pcs"},{"beans",100,"g"},{"cheese",50,"g"},{"onion",0.5,"pcs"}}},
            {"Carrot Soup", "1. Chop carrot, potato and onion. 2. Simmer with stock until soft. 3. Blend carefully until smooth.", new Object[][]{{"carrots",2,"pcs"},{"potato",1,"pcs"},{"onion",0.5,"pcs"},{"stock",300,"ml"}}},
            {"Yogurt Berry Parfait", "1. Spoon yogurt into a glass. 2. Layer with oats and berries. 3. Finish with honey.", new Object[][]{{"yogurt",150,"g"},{"oats",30,"g"},{"berries",50,"g"},{"honey",1,"tsp"}}},
            {"Peanut Butter Banana Toast", "1. Toast the bread. 2. Spread with peanut butter. 3. Add sliced banana on top.", new Object[][]{{"bread",2,"slices"},{"peanut butter",20,"g"},{"banana",1,"pcs"}}},
            {"Lemon Garlic Chicken", "1. Mix lemon juice, crushed garlic and olive oil. 2. Coat the chicken. 3. Cook the chicken thoroughly before serving.", new Object[][]{{"chicken",200,"g"},{"lemon",1,"pcs"},{"garlic",2,"cloves"},{"olive oil",1,"tbsp"}}},
            {"Mushroom Egg Toast", "1. Slice and cook mushrooms in butter. 2. Cook the eggs to your preference. 3. Serve over toasted bread.", new Object[][]{{"bread",2,"slices"},{"eggs",2,"pcs"},{"mushrooms",100,"g"},{"butter",10,"g"}}}
        };
        for (Object[] row : recipes) {
            ContentValues recipeValues = new ContentValues();
            recipeValues.put("name", (String) row[0]); recipeValues.put("steps", (String) row[1]);
            long recipeId = db.insert("recipes", null, recipeValues);
            Object[][] ingredients = (Object[][]) row[2];
            for (Object[] ingredient : ingredients) {
                ContentValues iv = new ContentValues(); iv.put("recipe_id", recipeId); iv.put("name", (String) ingredient[0]); iv.put("quantity", ((Number) ingredient[1]).doubleValue()); iv.put("unit", (String) ingredient[2]);
                db.insert("recipe_ingredients", null, iv);
            }
        }
    }
}
