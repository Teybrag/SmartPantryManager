package com.teybrag.smartpantry;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

public class IngredientFormActivity extends Activity {
    private DatabaseHelper db; private EditText name,quantity,unit,expiry; private long itemId=-1;
    @Override protected void onCreate(Bundle b){super.onCreate(b);db=new DatabaseHelper(this);itemId=getIntent().getLongExtra("item_id",-1);render();if(itemId!=-1)loadItem();}
    private void render(){LinearLayout root=Ui.vertical(this);Ui.title(this,root,itemId==-1?"Add ingredient":"Edit ingredient","Record what you have and how much is available.");
        name=field(root,"Ingredient name","e.g. tomatoes");quantity=field(root,"Quantity","e.g. 3 or 250");unit=field(root,"Unit","e.g. pcs, g, kg, ml, l, cups");expiry=field(root,"Expiry date (optional)","e.g. 2026-11-05");
        Button save=Ui.button(this,"Save ingredient",true);LinearLayout.LayoutParams p=Ui.lp(this,-1,49);p.topMargin=Ui.dp(this,18);root.addView(save,p);save.setOnClickListener(v->save());
        Button back=Ui.button(this,"Cancel",false);LinearLayout.LayoutParams bp=Ui.lp(this,-1,45);bp.topMargin=Ui.dp(this,8);root.addView(back,bp);back.setOnClickListener(v->finish());setContentView(Ui.scroll(this,root));}
    private EditText field(LinearLayout root,String label,String hint){root.addView(Ui.text(this,label,14,Ui.DARK,true),Ui.lp(this,-1,-2));EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(16);e.setHint(hint);e.setPadding(Ui.dp(this,12),Ui.dp(this,5),Ui.dp(this,12),Ui.dp(this,5));e.setBackground(Ui.round(this,Ui.WHITE,12));LinearLayout.LayoutParams p=Ui.lp(this,-1,51);p.topMargin=Ui.dp(this,5);p.bottomMargin=Ui.dp(this,13);root.addView(e,p);return e;}
    private void loadItem(){PantryItem item=db.getPantryItem(itemId);if(item!=null){name.setText(item.name);quantity.setText(String.valueOf(item.quantity));unit.setText(item.unit);expiry.setText(item.expiryDate);}}
    private void save(){String n=name.getText().toString().trim(),q=quantity.getText().toString().trim(),u=unit.getText().toString().trim(),e=expiry.getText().toString().trim();
        if(n.isEmpty()||q.isEmpty()||u.isEmpty()){Toast.makeText(this,"Name, quantity and unit are required.",Toast.LENGTH_LONG).show();return;}
        double amount;try{amount=Double.parseDouble(q);}catch(NumberFormatException ex){Toast.makeText(this,"Enter a valid number for quantity.",Toast.LENGTH_LONG).show();return;}
        if(amount<=0){Toast.makeText(this,"Quantity must be greater than zero.",Toast.LENGTH_LONG).show();return;}
        if(itemId==-1)db.addPantryItem(n,amount,u,e);else db.updatePantryItem(itemId,n,amount,u,e);
        Toast.makeText(this,"Ingredient saved.",Toast.LENGTH_SHORT).show();finish();}
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
