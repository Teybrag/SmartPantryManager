package com.teybrag.smartpantry;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.List;

public class RecipeAdapter extends BaseAdapter {
    private final Activity activity; private final List<Recipe> recipes;
    public RecipeAdapter(Activity activity,List<Recipe> recipes){this.activity=activity;this.recipes=recipes;}
    @Override public int getCount(){return recipes.size();}
    @Override public Object getItem(int p){return recipes.get(p);}
    @Override public long getItemId(int p){return recipes.get(p).id;}
    @Override public View getView(int position,View convertView,ViewGroup parent){
        Recipe r=recipes.get(position); LinearLayout card=new LinearLayout(activity); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(Ui.dp(activity,15),Ui.dp(activity,14),Ui.dp(activity,15),Ui.dp(activity,14)); card.setBackground(Ui.round(activity,Ui.WHITE,14));
        TextView name=Ui.text(activity,r.name,17,Ui.DARK,true); card.addView(name);
        TextView detail=Ui.text(activity,r.ingredients.size()+" required ingredients · Tap to view method",13,Ui.MUTED,false); detail.setPadding(0,Ui.dp(activity,5),0,0); card.addView(detail);
        LinearLayout.LayoutParams p=Ui.lp(activity,-1,-2);p.bottomMargin=Ui.dp(activity,10);card.setLayoutParams(p);return card;
    }
}
