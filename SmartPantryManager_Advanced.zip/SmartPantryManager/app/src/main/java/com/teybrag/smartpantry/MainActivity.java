package com.teybrag.smartpantry;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Dashboard for viewing, searching, creating, editing and deleting pantry items. */
public class MainActivity extends Activity {
    private DatabaseHelper db;
    private List<PantryItem> allItems = new ArrayList<>();
    private List<PantryItem> visibleItems = new ArrayList<>();
    private LinearLayout root;
    private ListView list;
    private EditText search;
    private TextView summary;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        db = new DatabaseHelper(this);
        render();
    }

    @Override protected void onResume() {
        super.onResume();
        if (db != null && search != null) refreshItems(search.getText().toString());
    }

    private void render() {
        root = Ui.vertical(this);
        Ui.title(this, root, "Smart Pantry", "Waste less. Cook smarter. Use what you already have.");
        Ui.nav(this, root);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(Ui.dp(this, 16), Ui.dp(this, 15), Ui.dp(this, 16), Ui.dp(this, 15));
        hero.setBackground(Ui.round(this, 0xFFE5F2E9, 18));
        summary = Ui.text(this, "Your pantry at a glance", 18, Ui.DARK, true);
        hero.addView(summary);
        TextView hint = Ui.text(this, "A recipe appears only when every required ingredient and quantity is available.", 13, Ui.MUTED, false);
        hint.setPadding(0, Ui.dp(this, 5), 0, 0);
        hero.addView(hint);
        LinearLayout.LayoutParams hp = Ui.lp(this, -1, -2);
        hp.bottomMargin = Ui.dp(this, 13);
        root.addView(hero, hp);

        Button add = Ui.button(this, "+  Add ingredient", true);
        root.addView(add, Ui.lp(this, -1, 48));
        add.setOnClickListener(v -> startActivity(new Intent(this, IngredientFormActivity.class)));
        Button recipes = Ui.button(this, "Find recipes I can make", false);
        LinearLayout.LayoutParams rp = Ui.lp(this, -1, 46);
        rp.topMargin = Ui.dp(this, 8);
        rp.bottomMargin = Ui.dp(this, 13);
        root.addView(recipes, rp);
        recipes.setOnClickListener(v -> startActivity(new Intent(this, SuggestedRecipesActivity.class)));

        TextView section = Ui.text(this, "Your ingredients", 19, Ui.DARK, true);
        root.addView(section, Ui.lp(this, -1, -2));
        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(15);
        search.setHint("Search your pantry");
        search.setPadding(Ui.dp(this, 13), Ui.dp(this, 4), Ui.dp(this, 13), Ui.dp(this, 4));
        search.setBackground(Ui.round(this, Ui.WHITE, 12));
        LinearLayout.LayoutParams searchParams = Ui.lp(this, -1, 48);
        searchParams.topMargin = Ui.dp(this, 8);
        searchParams.bottomMargin = Ui.dp(this, 8);
        root.addView(search, searchParams);

        list = new ListView(this);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setFocusable(false);
        list.setNestedScrollingEnabled(false);
        root.addView(list, Ui.lp(this, -1, -2));
        list.setOnItemClickListener((parent, view, position, id) -> {
            PantryItem item = visibleItems.get(position);
            Intent intent = new Intent(this, IngredientFormActivity.class);
            intent.putExtra("item_id", item.id);
            startActivity(intent);
        });
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            PantryItem item = visibleItems.get(position);
            new AlertDialog.Builder(this).setTitle("Delete ingredient?")
                .setMessage("Remove " + item.name + " from your pantry?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (dialog, which) -> {
                    db.deletePantryItem(item.id);
                    refreshItems(search.getText().toString());
                }).show();
            return true;
        });
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { refreshItems(s.toString()); }
            @Override public void afterTextChanged(Editable e) { }
        });
        setContentView(Ui.scroll(this, root));
        refreshItems("");
    }

    private void refreshItems(String query) {
        if (db == null || list == null) return;
        allItems = db.getAllPantryItems();
        visibleItems = new ArrayList<>();
        String needle = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        int expiring = 0;
        for (PantryItem item : allItems) {
            if (!needle.isEmpty() && !item.name.toLowerCase(Locale.ROOT).contains(needle)) continue;
            visibleItems.add(item);
        }
        for (PantryItem item : allItems) if (isExpiringSoon(item.expiryDate)) expiring++;
        summary.setText(allItems.size() + " ingredient" + (allItems.size() == 1 ? "" : "s") + " in your pantry" + (expiring > 0 ? "  ·  " + expiring + " expiring soon" : ""));
        if (visibleItems.isEmpty()) {
            list.setAdapter(null);
            TextView empty = Ui.text(this, allItems.isEmpty() ? "Your pantry is empty. Add your first ingredient to get started." : "No ingredients match that search.", 14, Ui.MUTED, false);
            empty.setPadding(Ui.dp(this, 4), Ui.dp(this, 16), Ui.dp(this, 4), Ui.dp(this, 16));
            empty.setTag("empty-state");
            list.setEmptyView(empty);
            // ListView needs an attached empty view; place a lightweight view in the root instead.
            if (empty.getParent() == null) {
                int index = root.indexOfChild(list);
                root.addView(empty, index + 1, Ui.lp(this, -1, -2));
            }
            list.setVisibility(View.GONE);
        } else {
            for (int i = root.getChildCount() - 1; i >= 0; i--) {
                View child = root.getChildAt(i);
                if (child instanceof TextView && child != summary && child != search && child != null && child.getTag() != null && "empty-state".equals(child.getTag())) root.removeViewAt(i);
            }
            list.setVisibility(View.VISIBLE);
            list.setAdapter(new PantryAdapter(this, visibleItems));
            // Give the embedded list enough height to display all rows inside the outer ScrollView.
            int rowHeight = Ui.dp(this, 78);
            list.getLayoutParams().height = Math.max(Ui.dp(this, 48), rowHeight * visibleItems.size());
            list.requestLayout();
        }
    }

    private boolean isExpiringSoon(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        try {
            java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.ROOT);
            format.setLenient(false);
            java.util.Date date = format.parse(value.trim());
            if (date == null) return false;
            long days = (date.getTime() - System.currentTimeMillis()) / (24L * 60L * 60L * 1000L);
            return days >= 0 && days <= 3;
        } catch (Exception ignored) { return false; }
    }

    @Override protected void onDestroy() {
        if (db != null) db.close();
        super.onDestroy();
    }
}
