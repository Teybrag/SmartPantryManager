package com.teybrag.smartpantry;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Strict matcher: each recipe ingredient must exist in enough quantity in a compatible unit. */
public final class PantryMatcher {
    private PantryMatcher() {}

    public static boolean canMake(Recipe recipe, List<PantryItem> pantry) {
        for (RecipeIngredient required : recipe.ingredients) {
            double available = 0.0;
            for (PantryItem item : pantry) {
                if (!normalizeName(item.name).equals(normalizeName(required.name))) continue;
                double converted = convertToBase(item.quantity, item.unit);
                double needed = convertToBase(required.quantity, required.unit);
                if (Double.isNaN(converted) || Double.isNaN(needed) || !unitFamily(item.unit).equals(unitFamily(required.unit))) continue;
                available += converted;
            }
            double neededBase = convertToBase(required.quantity, required.unit);
            if (Double.isNaN(neededBase) || available + 0.000001 < neededBase) return false;
        }
        return true;
    }

    public static String normalizeName(String raw) {
        String n = raw == null ? "" : raw.toLowerCase(Locale.ROOT).trim().replaceAll("[^a-z0-9 ]", "").replaceAll("\\s+", " ");
        if (n.endsWith("ies") && n.length() > 4) return n.substring(0, n.length() - 3) + "y";
        if (n.endsWith("oes") && n.length() > 4) return n.substring(0, n.length() - 2); // tomatoes -> tomato
        if (n.endsWith("s") && !n.endsWith("ss") && n.length() > 3) return n.substring(0, n.length() - 1);
        return n;
    }

    private static String normalizedUnit(String raw) {
        String u = raw == null ? "" : raw.toLowerCase(Locale.ROOT).trim();
        if (u.equals("grams") || u.equals("gram")) return "g";
        if (u.equals("kilograms") || u.equals("kilogram")) return "kg";
        if (u.equals("millilitres") || u.equals("milliliters") || u.equals("millilitre") || u.equals("milliliter")) return "ml";
        if (u.equals("litres") || u.equals("liters") || u.equals("litre") || u.equals("liter")) return "l";
        if (u.equals("pieces") || u.equals("piece") || u.equals("pcs") || u.equals("each") || u.equals("items")) return "pcs";
        if (u.equals("clove")) return "cloves";
        if (u.equals("slice")) return "slices";
        if (u.equals("cup")) return "cups";
        if (u.equals("tablespoon")) return "tbsp";
        if (u.equals("tablespoons")) return "tbsp";
        if (u.equals("teaspoon") || u.equals("teaspoons")) return "tsp";
        return u;
    }

    private static String unitFamily(String raw) {
        String u = normalizedUnit(raw);
        if (u.equals("g") || u.equals("kg")) return "mass";
        if (u.equals("ml") || u.equals("l")) return "volume";
        if (u.equals("tsp") || u.equals("tbsp")) return "spoon";
        if (u.equals("cups")) return "cup";
        if (u.equals("pcs") || u.equals("cloves") || u.equals("slices") || u.equals("can")) return u;
        return "other:" + u;
    }

    private static double convertToBase(double amount, String rawUnit) {
        String u = normalizedUnit(rawUnit);
        switch (u) {
            case "g": return amount;
            case "kg": return amount * 1000.0;
            case "ml": return amount;
            case "l": return amount * 1000.0;
            case "tbsp": return amount * 3.0; // teaspoons
            case "tsp": return amount;
            case "cups": return amount; // cups compare only with cups
            case "pcs": case "cloves": case "slices": case "can": return amount;
            default: return Double.NaN;
        }
    }
}
