package com.teybrag.smartpantry;

public class RecipeIngredient {
    public long id;
    public long recipeId;
    public String name;
    public double quantity;
    public String unit;

    public RecipeIngredient(long id, long recipeId, String name, double quantity, String unit) {
        this.id = id;
        this.recipeId = recipeId;
        this.name = name;
        this.quantity = quantity;
        this.unit = unit;
    }
}
