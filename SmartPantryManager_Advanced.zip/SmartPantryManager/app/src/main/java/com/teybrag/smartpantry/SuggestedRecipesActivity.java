package com.teybrag.smartpantry;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class SuggestedRecipesActivity extends Activity {
    private DatabaseHelper db; private List<Recipe> matches;
    @Override protected void onCreate(Bundle b){super.onCreate(b);db=new DatabaseHelper(this);render();}
    @Override protected void onResume(){super.onResume();if(db!=null)render();}
    private void render(){LinearLayout root=Ui.vertical(this);Ui.title(this,root,"Suggested recipes","Every suggestion passes the strict pantry check.");Ui.nav(this,root);
        List<PantryItem> pantry=db.getAllPantryItems();matches=new ArrayList<>();for(Recipe r:db.getAllRecipes())if(PantryMatcher.canMake(r,pantry))matches.add(r);
        TextView count=Ui.text(this,matches.size()+" recipe"+(matches.size()==1?"":"s")+" you can make",17,Ui.DARK,true);LinearLayout.LayoutParams cp=Ui.lp(this,-1,-2);cp.bottomMargin=Ui.dp(this,12);root.addView(count,cp);
        if(matches.isEmpty()){TextView empty=Ui.text(this,"No recipes match your pantry yet. Add more ingredients or check the quantities you entered.",15,Ui.MUTED,false);empty.setPadding(Ui.dp(this,16),Ui.dp(this,25),Ui.dp(this,16),Ui.dp(this,25));empty.setBackground(Ui.round(this,Ui.WHITE,14));root.addView(empty);Button add=Ui.button(this,"Add ingredients",true);LinearLayout.LayoutParams ap=Ui.lp(this,-1,48);ap.topMargin=Ui.dp(this,12);root.addView(add,ap);add.setOnClickListener(v->startActivity(new Intent(this,MainActivity.class)));}
        else {ListView list=new ListView(this);list.setDivider(null);list.setDividerHeight(0);list.setAdapter(new RecipeAdapter(this,matches));root.addView(list,new LinearLayout.LayoutParams(-1,0,1));list.setOnItemClickListener((p,v,pos,id)->{Intent i=new Intent(this,RecipeDetailActivity.class);i.putExtra("recipe_id",matches.get(pos).id);startActivity(i);});}
        setContentView(Ui.scroll(this,root));}
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
