package com.teybrag.smartpantry;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class Ui {
    public static final int GREEN = Color.rgb(35, 116, 75);
    public static final int DARK = Color.rgb(28, 45, 36);
    public static final int MUTED = Color.rgb(105, 120, 111);
    public static final int BG = Color.rgb(246, 248, 245);
    public static final int WHITE = Color.WHITE;
    private Ui() {}

    public static int dp(Activity a, int value) { return (int)(value * a.getResources().getDisplayMetrics().density + 0.5f); }
    public static LinearLayout vertical(Activity a) { LinearLayout l = new LinearLayout(a); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(a,20), dp(a,18), dp(a,20), dp(a,20)); l.setBackgroundColor(BG); return l; }
    public static TextView text(Activity a, String value, int size, int color, boolean bold) { TextView t = new TextView(a); t.setText(value); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setGravity(Gravity.CENTER_VERTICAL); return t; }
    public static Button button(Activity a, String value, boolean primary) { Button b = new Button(a); b.setText(value); b.setAllCaps(false); b.setTextSize(15); b.setTextColor(primary ? WHITE : GREEN); if (primary) { b.setBackground(round(a, GREEN, 14)); } else { b.setBackground(round(a, WHITE, 14)); } b.setPadding(dp(a,12), dp(a,7), dp(a,12), dp(a,7)); return b; }
    public static GradientDrawable round(Activity a, int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(a,radius)); return d; }
    public static LinearLayout.LayoutParams lp(Activity a, int width, int height) { return new LinearLayout.LayoutParams(width < 0 ? width : dp(a,width), height < 0 ? height : dp(a,height)); }
    public static void title(Activity a, LinearLayout root, String title, String subtitle) { TextView t = text(a,title,27,DARK,true); root.addView(t, lp(a,-1,-2)); TextView s = text(a,subtitle,14,MUTED,false); s.setPadding(0,dp(a,4),0,dp(a,17)); root.addView(s,lp(a,-1,-2)); }
    public static void nav(Activity a, LinearLayout root) {
        LinearLayout row = new LinearLayout(a); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER);
        Button pantry = button(a,"Pantry",false), recipes = button(a,"Recipes",false), settings = button(a,"Settings",false);
        row.addView(pantry,new LinearLayout.LayoutParams(0,dp(a,44),1)); row.addView(recipes,new LinearLayout.LayoutParams(0,dp(a,44),1)); row.addView(settings,new LinearLayout.LayoutParams(0,dp(a,44),1));
        pantry.setOnClickListener(v -> a.startActivity(new android.content.Intent(a,MainActivity.class)));
        recipes.setOnClickListener(v -> a.startActivity(new android.content.Intent(a,SuggestedRecipesActivity.class)));
        settings.setOnClickListener(v -> a.startActivity(new android.content.Intent(a,SettingsActivity.class)));
        LinearLayout.LayoutParams p=lp(a,-1,44); p.bottomMargin=dp(a,15); root.addView(row,p);
    }
    public static ScrollView scroll(Activity a, View child) { ScrollView s = new ScrollView(a); s.setFillViewport(true); s.addView(child); return s; }
}
