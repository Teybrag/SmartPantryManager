package com.teybrag.smartpantry;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

public class RecipeDetailActivity extends Activity {
    private DatabaseHelper db;
    @Override protected void onCreate(Bundle b){super.onCreate(b);db=new DatabaseHelper(this);render();}
    private void render(){long id=getIntent().getLongExtra("recipe_id",-1);Recipe r=db.getRecipe(id);LinearLayout root=Ui.vertical(this);if(r==null){Ui.title(this,root,"Recipe not found","It may have been removed.");setContentView(Ui.scroll(this,root));return;}
        Ui.title(this,root,r.name,"Made only from the ingredients checked in your pantry.");Ui.nav(this,root);
        root.addView(Ui.text(this,"Ingredients",20,Ui.DARK,true),Ui.lp(this,-1,-2));
        for(RecipeIngredient ing:r.ingredients){String q=String.format(Locale.getDefault(),"%s %s",ing.quantity==(long)ing.quantity?String.valueOf((long)ing.quantity):String.valueOf(ing.quantity),ing.unit);TextView row=Ui.text(this,"•  "+q+"  "+ing.name,15,Ui.DARK,false);row.setPadding(Ui.dp(this,12),Ui.dp(this,8),Ui.dp(this,12),Ui.dp(this,8));LinearLayout.LayoutParams p=Ui.lp(this,-1,-2);p.topMargin=Ui.dp(this,4);row.setBackground(Ui.round(this,Ui.WHITE,10));root.addView(row,p);}
        TextView method=Ui.text(this,"Preparation",20,Ui.DARK,true);LinearLayout.LayoutParams mp=Ui.lp(this,-1,-2);mp.topMargin=Ui.dp(this,20);mp.bottomMargin=Ui.dp(this,8);root.addView(method,mp);
        TextView steps=Ui.text(this,r.steps,15,Ui.DARK,false);steps.setPadding(Ui.dp(this,14),Ui.dp(this,14),Ui.dp(this,14),Ui.dp(this,14));steps.setBackground(Ui.round(this,Ui.WHITE,14));root.addView(steps,Ui.lp(this,-1,-2));
        Button back=Ui.button(this,"Back to suggestions",true);LinearLayout.LayoutParams bp=Ui.lp(this,-1,48);bp.topMargin=Ui.dp(this,18);root.addView(back,bp);back.setOnClickListener(v->finish());setContentView(Ui.scroll(this,root));}
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
