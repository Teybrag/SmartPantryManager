package com.teybrag.smartpantry;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

public class SettingsActivity extends Activity {
    @Override protected void onCreate(Bundle b){super.onCreate(b);LinearLayout root=Ui.vertical(this);Ui.title(this,root,"Settings","Choose how Smart Pantry works for you.");Ui.nav(this,root);
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(Ui.dp(this,16),Ui.dp(this,14),Ui.dp(this,16),Ui.dp(this,14));card.setBackground(Ui.round(this,Ui.WHITE,14));
        Switch alerts=new Switch(this);alerts.setText("Expiry reminders");alerts.setTextSize(16);alerts.setTextColor(Ui.DARK);alerts.setChecked(getPreferences(MODE_PRIVATE).getBoolean("expiry_alerts",true));alerts.setOnCheckedChangeListener((button,checked)->getPreferences(MODE_PRIVATE).edit().putBoolean("expiry_alerts",checked).apply());card.addView(alerts);
        TextView note=Ui.text(this,"This preference is saved on this device. Automatic notifications are not implemented in this assignment starter.",13,Ui.MUTED,false);note.setPadding(0,Ui.dp(this,8),0,0);card.addView(note);root.addView(card,Ui.lp(this,-1,-2));
        TextView dbNote=Ui.text(this,"Storage: SQLite database on this device. Pantry records remain saved when you close and reopen the app.",14,Ui.DARK,false);dbNote.setPadding(Ui.dp(this,15),Ui.dp(this,15),Ui.dp(this,15),Ui.dp(this,15));dbNote.setBackground(Ui.round(this,0xFFE5F2E9,14));LinearLayout.LayoutParams p=Ui.lp(this,-1,-2);p.topMargin=Ui.dp(this,14);root.addView(dbNote,p);setContentView(Ui.scroll(this,root));}
}
