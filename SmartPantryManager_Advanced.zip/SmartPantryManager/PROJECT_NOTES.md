# Development and test notes

## Important manual tests

1. Add `eggs`, quantity `1`, unit `pcs`. Confirm the item appears on the dashboard after saving.
2. Add the remaining ingredients for a seeded recipe and open Suggested Recipes. The recipe should appear only after all required quantities are present.
3. Reduce a required quantity below the recipe requirement or delete a required item. Confirm that recipe disappears from strict suggestions.
4. Tap an ingredient to edit it; change quantity and save. Long-press an ingredient to delete it and confirm the confirmation dialog.
5. Add an ISO date (`YYYY-MM-DD`) within three days to an ingredient and confirm the dashboard shows an expiring-soon indicator. This is a visual indicator, not an OS notification.
6. Close and reopen the app. Confirm pantry data remains saved.
7. Test search with a partial ingredient name and with a search that has no results.

## Known boundaries

- Expiry dates must use `YYYY-MM-DD` for the visual status check.
- Ingredient synonyms beyond basic singular/plural normalisation are not inferred automatically.
- Cooking measures such as a cup of flour cannot be reliably converted to grams without ingredient-specific density data.
- The settings toggle stores the user's preference locally; it does not schedule Android notifications.
- The generated debug APK is not a Play Store release build.
